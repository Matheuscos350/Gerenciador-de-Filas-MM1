# Gerenciador defilas de atendimento
## Sobre   
Um aplicativo feito para Testar minhas habilidades, utilizando HTML semântico, CSS e Javascript com Array.

---

## Tecnologias e ferramentas utilizadas
- **HTML5**
- **CSS3**
- **Javascript** (com Array).

---

## Demonstração

![](https://i.imgur.com/faqOyXb.png)   

Acesse o projeto clicando [aqui](https://guilhermesdb.github.io/Gerenciador-de-filas-de-atendimento/).
