var prioritario = [];
var comum = [];
var rapido = [];
let senhaCliente;



// Função para contar os clicks        
let clicks = 0;
function click(){
    clicks += 1; 
}

function senhaClientes() {
    document.getElementById("senha-clientes").innerHTML = senhaCliente;
}

// Funções para adicionar uma senha aos Arrays 
function addComum(){
    click(); // Chama a função click
    senhaCliente = "C-"+clicks; // Adiciona o tipo da senha + o Click numa variavel
    comum.push("C-"+clicks); // Adiciona o tipo da senha + o click no Array
    senhaClientes();// Exibe a senha do Cliente no painel

    // Registra o tempo de chegada do cliente
    tempoChegada.push(new Date());
}

function addRapido(){
    click();
    senhaCliente = "R-"+clicks;
    rapido.push("R-"+clicks);
    senhaClientes();

    // Registra o tempo de chegada do cliente
    tempoChegada.push(new Date());
}


// Função para chamar as senhas Rapidas, com verificação.   
function chamarRapido(){
    if(rapido.length > 0){
        let cliente = rapido[0];
        document.getElementById("visor-tela").innerHTML = cliente;
        rapido.shift();
        document.getElementById("numero-caixa").innerHTML = event.target.id;

        // Registra o tempo de partida do cliente
        tempoPartida.push(new Date());

        calcularTempoMedioEspera(tempoChegada[tempoChegada.length - 1], tempoPartida[tempoPartida.length - 1]);
    }else{
        chamarPrioritario();
    }
}

// Função para chamar as senhas Prioritarias, com verificação.        
function chamarPrioritario(){            
    if(prioritario.length > 0){
        let cliente = prioritario[0];
        document.getElementById("visor-tela").innerHTML = cliente;
        prioritario.shift();
        document.getElementById("numero-caixa").innerHTML = event.target.id;

        // Registra o tempo de partida do cliente
        tempoPartida.push(new Date());

        calcularTempoMedioEspera(tempoChegada[tempoChegada.length - 1], tempoPartida[tempoPartida.length - 1]);
    }else if(rapido.length > 0){
        chamarRapido();
    }else if (comum.length > 0){
        chamarComum();
    }else{
        document.getElementById("visor-tela").innerHTML = "Nao ha Senhas";
    }
}

// Função para chamar as senhas Comums, com verificação.  
function chamarComum(){  
    if(comum.length >0){
        let cliente = comum[0];
        document.getElementById("visor-tela").innerHTML = cliente;
        comum.shift();
        document.getElementById("numero-caixa").innerHTML = event.target.id;

        // Registra o tempo de partida do cliente
        tempoPartida.push(new Date());

        calcularTempoMedioEspera(tempoChegada[tempoChegada.length - 1], tempoPartida[tempoPartida.length - 1]);
    }else{
        chamarPrioritario();
    } 
}

// Função para calcular o tempo médio de espera e exibir no HTML
function calcularTempoMedioEspera(tempoChegada, tempoPartida) {
    const tempoEspera = tempoPartida - tempoChegada; // Tempo que o cliente passou na fila (em milissegundos)
    const tempoMedioEsperaSegundos = tempoEspera / 1000; // Convertendo para segundos
    const tempoMedioEsperaFormatado = Math.round(tempoMedioEsperaSegundos) + " segundos";

    // Atualiza o conteúdo do elemento HTML com o tempo médio de espera
    document.getElementById("tempo-medio-espera").innerText = "Tempo médio de espera: " + tempoMedioEsperaFormatado;
}

// Pega todos os botões que existem com a class botoes
const checkButtons = document.querySelectorAll(".botoes")

checkButtons.forEach( button => {
    //adicionar a escuta
    button.addEventListener("click" , handleClick)
})        

// Quando o botao for clicado, registra o evento e entra no IF          
function handleClick(event){
    event.preventDefault();
    if(event.target.id == "btn-comum" ){
        addComum();
    }else if(event.target.id == "btn-rapido"){
        addRapido();
    }else if(event.target.id == "btn-prioridade"){
        addPrioritario();
    }else if(event.target.id == "Caixa 1"){
        chamarPrioritario();
    }
}


// Função para calcular o tempo médio entre chegadas
function calcularTempoMedioEntreChegadas(tempoChegada) {
    const totalClientes = tempoChegada.length;
    const tempoTotalEntreChegadas = tempoChegada.reduce((acc, curr, index) => {
        if (index !== 0) {
            acc += curr - tempoChegada[index - 1];
        }
        return acc;
    }, 0);
    return tempoTotalEntreChegadas / (totalClientes - 1);
}


// Variáveis para rastrear o tempo de chegada e partida de cada cliente
let tempoChegada = []; //la
let tempoPartida = []; //mi

// Função para calcular o tempo provável na fila
function calcularTempoProvavelFila(tempoChegada, tempoPartida) {
    return 1 / (tempoPartida - tempoChegada);
}

// Função para calcular o tempo provável no sistema
function calcularTempoProvavelSistema(tempoChegada, tempoPartida) {
    return calcularTempoProvavelFila(tempoChegada, tempoPartida);
}

// Função para calcular a probabilidade da fila estar vazia
function calcularProbabilidadeFilaVazia(tempoChegada, tempoPartida) {
    return 1 - (tempoChegada / tempoPartida);
}

// Função para calcular a probabilidade do sistema estar vazio
function calcularProbabilidadeSistemaVazio(tempoChegada, tempoPartida) {
    return 1 / (1 + (tempoChegada / tempoPartida));
}

// Função para calcular a ocupação do sistema
function calcularOcupacaoSistema(tempoChegada, tempoPartida) {
    return tempoChegada / tempoPartida;
}

// Função para calcular o número provável de clientes no sistema
function calcularNumeroProvavelSistema(tempoChegada, tempoPartida) {
     return tempoChegada / (tempoPartida - tempoChegada);
}

// Função para calcular o número provável de clientes na fila
function calcularNumeroProvavelFila(tempoChegada, tempoPartida) {
    return (tempoChegada * tempoChegada) / (tempoPartida * (tempoPartida - tempoChegada));
}

// Exemplo de uso:

console.log("Tempo médio entre chegadas:", calcularTempoMedioEntreChegadas(tempoChegada));
console.log("Tempo médio de atendimento:", calcularTempoMedioAtendimento(tempoPartida));
console.log("Tempo provável na fila:", calcularTempoProvavelFila(tempoChegada, tempoPartida));
console.log("Tempo provável no sistema:", calcularTempoProvavelSistema(tempoChegada, tempoPartida));
console.log("Probabilidade da fila estar vazia:", calcularProbabilidadeFilaVazia(tempoChegada, tempoPartida));
console.log("Probabilidade do sistema estar vazio:", calcularProbabilidadeSistemaVazio(tempoChegada, tempoPartida));
console.log("Ocupação do sistema:", calcularOcupacaoSistema(tempoChegada, tempoPartida));
console.log("Número provável de clientes no sistema:", calcularNumeroProvavelSistema(tempoChegada, tempoPartida));
console.log("Número provável de clientes na fila:", calcularNumeroProvavelFila(tempoChegada, tempoPartida));
