<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Imports -->
    <link rel="stylesheet" href="style.css" type="text/css">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;900&display=swap" rel="stylesheet">
    <title>Gerenciador de Filas MM1</title>

    <script src="funcoes.js" async></script>
    
</head>
<body>
    
    <div class="container">
        <header>
            <div class="nome-banco">
                <div id="tempo-medio-espera" class="conteudo-caixa">...</div>
            </div>
        </header>

        <div class="content">

            <div class="senha-chamada">
                <h1 id="visor-tela">--</h1><br>
                <div class="conteudo-senha-chamada">
                    dirigir-se ao <span id="numero-caixa" class="conteudo-caixa"> -- </span>
                </div>
                
            </div>

            <div class="container-final">


                <div class="para-clientes">                     
                    
                    <div class="para-cliente">
                        <h5 class="title-content-final">
                            para clientes
                        </h5>
                        <h1 class="subtitle-content-final">escolha seu tipo de atendimento:</h1>
                        <div class="grupo-de-botoes">
                            <button id="btn-comum" class="botoes"> 
                                Comum
                            </button>
    
                            <button id="btn-rapido" class="botoes"> 
                                Rapido
                            </button>

                        </div>  
                    </div>

                    <div class="content-final-div">
                        sua senha é:
                        <h1 id="senha-clientes">--</h1>
                    </div>  

                </div>
    
                <div class="para-caixas">
                    <h5 class="title-content-final">
                        para caixas
                    </h5>
                    <h1 class="subtitle-content-final">clique para chamar uma senha:</h1>
                    <div id="buttons-caixa" class="grupo-de-botoes">
                        <button id="Caixa 1" class="botoes">Caixa 1</button>
                    </div> 
                    
                </div>

            </div>

   

        </div>
    </div>
</body>
<html>
